#!/bin/sh
: ${SHELLY_HOME:="$HOME/.shelly"}
export SHELLY_HOME
PATH="$SHELLY_HOME/bin:$PATH"
export PATH
